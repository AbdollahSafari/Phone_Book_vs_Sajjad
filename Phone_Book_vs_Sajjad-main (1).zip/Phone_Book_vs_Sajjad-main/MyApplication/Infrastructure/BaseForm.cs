﻿namespace Infrastructure;

public partial class BaseForm : System.Windows.Forms.Form
{
	public BaseForm() : base()
	{
		InitializeComponent();
	}
}
