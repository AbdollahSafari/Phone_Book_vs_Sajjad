﻿namespace Dtat.Windows.Forms;

public class ListBox : System.Windows.Forms.ListBox
{
	public ListBox() : base()
	{
	}
}
