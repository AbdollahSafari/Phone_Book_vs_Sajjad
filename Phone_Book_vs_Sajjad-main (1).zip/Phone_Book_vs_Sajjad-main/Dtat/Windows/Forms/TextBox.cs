﻿namespace Dtat.Windows.Forms;

public class TextBox : System.Windows.Forms.TextBox
{
	public TextBox() : base()
	{
	}
}
