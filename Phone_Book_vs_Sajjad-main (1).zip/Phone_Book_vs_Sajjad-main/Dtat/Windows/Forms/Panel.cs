﻿namespace Dtat.Windows.Forms;

public class Panel : System.Windows.Forms.Panel
{
	public Panel() : base()
	{
	}
}
