﻿namespace Dtat.Windows.Forms;

public class DataGridView : System.Windows.Forms.DataGridView
{
	public DataGridView() : base()
	{
	}
}
