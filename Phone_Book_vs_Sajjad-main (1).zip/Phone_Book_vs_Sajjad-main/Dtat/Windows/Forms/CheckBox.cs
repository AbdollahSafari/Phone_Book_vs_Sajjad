﻿namespace Dtat.Windows.Forms;

public class CheckBox : System.Windows.Forms.CheckBox
{
	public CheckBox() : base()
	{
	}
}
