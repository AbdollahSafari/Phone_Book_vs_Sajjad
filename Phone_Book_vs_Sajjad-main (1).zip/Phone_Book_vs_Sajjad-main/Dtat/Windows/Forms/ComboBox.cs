﻿namespace Dtat.Windows.Forms;

public class ComboBox : System.Windows.Forms.ComboBox
{
	public ComboBox() : base()
	{
	}
}
