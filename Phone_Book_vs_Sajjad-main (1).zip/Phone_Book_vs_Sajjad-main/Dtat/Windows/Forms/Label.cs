﻿namespace Dtat.Windows.Forms;

public class Label : System.Windows.Forms.Label
{
	public Label() : base()
	{
	}
}
